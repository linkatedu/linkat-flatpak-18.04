#!/bin/bash

sudo add-apt-repository ppa:alexlarsson/flatpak
sudo apt update
sudo apt install flatpak
